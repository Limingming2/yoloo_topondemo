//
//  KXGamingSDK.h
//  KXGamingSDK
//
//  Created by lmm on 2019/7/19.
//  Copyright © 2019 kaixin001.com. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <YLGamingSDK/YLRewardedVideoAdReward.h>
#import <YLGamingSDK/YLRewardedVideoAd.h>
#import <YLGamingSDK/YLInterstitialAd.h>
#import <YLGamingSDK/YLBannerAdView.h>
#import <YLGamingSDK/YLAnalysis.h>
#import <YLGamingSDK/YLAbTestCenter.h>
#import <YLGamingSDK/YLDeviceId.h>
#import <YLGamingSDK/YLCloudConfigManager.h>
#import <YLGamingSDK/YLInterstitialAdUtils.h>
