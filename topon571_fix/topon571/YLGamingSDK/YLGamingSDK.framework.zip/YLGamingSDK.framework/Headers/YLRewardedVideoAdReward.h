//
// Created by Leon
// Copyright (c) 2019 kaixin001.com. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface YLRewardedVideoAdReward : NSObject
@end
