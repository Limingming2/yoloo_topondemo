//
//  YLInterstitialAdUtils.h
//  YLGamingSDK
//
//  Created by lmm on 2020/7/23.
//  Copyright © 2020 kaixin001.com. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface YLInterstitialAdUtils : NSObject
+ (BOOL)canShowInterstitial:(nullable NSString *)key;
@end

NS_ASSUME_NONNULL_END
